<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Satisfy&display=swap" rel="stylesheet">


    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

    <title><?php echo e($title); ?></title>
</head>
<body>
   <div class="container-fluid bg-dark">
      <div class="row">
          <div class="col-sm-2">
              <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
          <div class="col-sm-10">
              <?php echo e($content); ?>

      </div>
      

   </div>
     <script src="<?php echo e(asset('js/all.js')); ?>"></script>

<script src="<?php echo e(asset('js/bootstrap.bundle.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\asus\Desktop\laravel 2\resumeproject1\resources\views/components/layout.blade.php ENDPATH**/ ?>