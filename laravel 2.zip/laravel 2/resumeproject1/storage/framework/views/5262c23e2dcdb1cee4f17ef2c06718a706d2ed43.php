<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Home <?php $__env->endSlot(); ?>
     <?php $__env->slot('content', null, []); ?>  Main Content
        <div class="mt-5">
            <div class="text-center">
                <img src="<?php echo e(asset('images/kamal2.jpg')); ?>" alt="" class="img-thumbnail" width="250px" height="150px">
            </div>
            <div class="mt-5 text-white mx=5 text-justify">
                <h1 class="fw-bold st-font">Hello,</h1>
                <div class="px-4" style="line-height: 2rem;">
                <p style="text-indent:100px"> I am <b class="text-warning"> Ashish Kumar Singh  </b> having 1 year of full-stack web development experience
            and  good problem solving skils </p>

                </div>

            </div>

            <div class="text-center">
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-outline-warning mx-5 my-3">Hire Me</a>
                <a href="<?php echo e(route('contact')); ?>" class="btn btn-outline-info">Contact</a>
            </div>

        </div>
        <i class="fas fa-map-market-alt fa-2x i-color"></i>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?><?php /**PATH C:\laravel\resumeproject1\resources\views/home.blade.php ENDPATH**/ ?>