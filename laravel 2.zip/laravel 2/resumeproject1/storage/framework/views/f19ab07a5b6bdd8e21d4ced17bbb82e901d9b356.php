<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Skill <?php $__env->endSlot(); ?>
     <?php $__env->slot('content', null, []); ?> 
        <div class="container mt-5">
            <h1 class="text-warning mb-5 border-bottom">SKILLS</h1>
        <div class="row text-white">
            <div class="col-sm-5">
                <h3 class=mt-5">HTML/CSS</h3>
                <div class="progress">
                    <div class="progress-bar bg-danger" role="progressbar" style="width:100%" aria-valuemiin="0" aria-valuemax="100" aria-valuemin="0"
                    aria-valuemax="100">100%</div>
</div>
</div>
<div class="col-sm-5 offset-sm-2">
    <h3 class="mt-5">JavaScript</h3>
    <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
        style="width:95%" aria-valuenow="95" aria-valuemin="0"
        aria-valuemax="100">95%</div>
</div>
</div>
<div class="col-sm-5">
    <h3 class="mt-5"> Java Programming</h3>
    <div class="progress">
        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"
        style="width: 90%">90%</div>
</div>
</div>
<div class=col-sm-5 offset-sm-2">
<h3 class="mt-5">Python</h3>
<div class="progress">
    <div class="progress-bar progress-bar-striped
    progress-bar-animated" role="progressbar"
    aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"
    style="width:95%">95%</div>
</div>
</div>
<div class="col-sm-5">
    <h3 class="mt-5">SQL</h3>
    <div class="progress">
        <div class="progress-bar progress-bar-striped
        progress-bar-animated" role="progressbar"
        aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"
        style="width: 95%">95%</div>
</div>
</div>
<div class="col-sm-5 offset-sm-2">
    <h3 class="mt-5">Django<h3>
        <div class="progress">
            <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" 
            aria-valuenow="45" aria-valuemin="0" aria-valuemax="100"
                style="width: 45%">45%</div>
</div>
</div>

            <div class="col-sm-5 offset-sm-2">
            <h3 class="mt-5">Julia Programming</h3>
            <div class="progress">
                <div class="progress-bar progress-bar-striped progress-bar-animated bg-info" role="progressbar"
                aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"
                style="width: 30%">30%</div>
</div>
</div>
</div>
</div>
 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php /**PATH C:\laravel\resumeproject1\resources\views/skill.blade.php ENDPATH**/ ?>