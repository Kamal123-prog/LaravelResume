<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Contact <?php $__env->endSlot(); ?>
     <?php $__env->slot('content', null, []); ?> 
      <div class="container mt-5">
          <h1 class="text-warning mb-5 border-bottom">CONTACT US</h1>
          <div class="row text-white mb-5">
              <p class="mx-auto mb-5">
                  Hey there ,feel free to ask any of your doubts ,I will definitely be answering all the questions
              </p>
              <div class="col-sm-9 mb-5">
                  <form action="">
                      <div class="row g-3">
                          <div class="col-md-6">
                              <label for="inputName">Your Name</label>
                              <input type="text" class="form-control mt-2" id="inputName" />
                          </div>
                          <div class="col-md-6">
                              <label for="inputEmail">Your Email *</label>
                              <input type="email" class="form-control mt-2" id="inputEmail" required />
                          </div>
                          <div class="col-md-12">
                              <label for="inputSubject">Your Subject</label>
                              <input type="text" class="form-control mt-2" id="inputSubject" />
                          </div>
                          <div class="col-md-12 mb-3">
                              <label for="inputTextArea">Your message *</label>
                              <textarea class="form-control mt-2" id="inputTextArea" required></textarea>
                          </div>
                      </div>
                      <button class="btn btn-primary" type="submit">Send</button>
                  </form>
              </div>
              <div class="col-sm-3 text-center">
                  <ul class="list-unstyled">
                      <li>
                          <i class="fas fa-map-marker-alt fa-2x i-color"></i>
                          <p>Kolkata,West Bengal,India</p>
                      </li>
                      <li>
                          <i class="fas fa-envelope mt-4 fa-2x i-color"></i>
                          <p>contact@gmail.com</p>
                      </li>
                  </ul>
              </div>
          </div>
      </div>  
      <div class="text-center">
          <a href="#" target="_blank"><i class="fab fa-twitter i-color"></i></a>
          <a href="#" target="_blank"><i class="fab fa-instagram i-color mx-3"></i></a>
          <a href="#" target="_blank"><i class="fab fa-linkedin i-color mx-3"></i></a>
      </div>
 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?><?php /**PATH C:\laravel\resumeproject1\resources\views/contact.blade.php ENDPATH**/ ?>